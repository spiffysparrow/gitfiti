var Dispatcher = require('flux').Dispatcher;
module.exports = new Dispatcher();
